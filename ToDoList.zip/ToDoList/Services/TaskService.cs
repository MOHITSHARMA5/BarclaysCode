﻿using System.Collections.Concurrent;
using System.ComponentModel.DataAnnotations;
using TasksList.Models;

namespace ToDoList.Services
{
    public class TaskService : ITaskService
    {

        static List<TaskViewModel> taskListFinal = new List<TaskViewModel>();
        public TaskService()
        {

        }

        public void DeleteTask(int id)
        {
            lock (taskListFinal)
            {
                var task = taskListFinal.FirstOrDefault(v => v.Id == id);
                if (task.TaskStatus != Status.Completed)
                    throw new Exception("Task Not completed!!");
                taskListFinal.Remove(task);
            }
        }

        public TaskViewModel GetTaskById(int id)
        {
            var task = taskListFinal.FirstOrDefault(v => v.Id == id);
            return task;
        }

        public TaskViewModel GetTaskByName(string name)
        {
            var task = taskListFinal.FirstOrDefault(t => string.Equals(t.Name, name.Trim(), StringComparison.CurrentCultureIgnoreCase));
            return task;
        }

        public IEnumerable<TaskViewModel> GetTasks()
        {
            return taskListFinal;
        }

        public TaskViewModel AddOrUpdateTask(int? id, TaskViewModel task)
        {

            lock (taskListFinal)
            {
                var updatedTask = taskListFinal.FirstOrDefault(v => v.Id == id) ?? new TaskViewModel();
                updatedTask.Name = task.Name;
                updatedTask.Priority = task.Priority;
                updatedTask.TaskStatus = task.TaskStatus;
                if (updatedTask.Id == 0)
                {
                    updatedTask.Id = taskListFinal.Count == 0 ? 1 : taskListFinal.Select(t => t.Id).Max() + 1;
                    taskListFinal.Add(updatedTask);
                }
                return updatedTask;
            }
        }
        
        public bool IsValidTaskName(string name, int? id)
        {
            var duplicateTask = GetTaskByName(name);
            if (duplicateTask != null && duplicateTask.Id != id)
            {
                return false;
            }
            return true;
        }

    }
}
