﻿using TasksList.Models;

namespace ToDoList.Services
{
    public interface ITaskService
    {
        public IEnumerable<TaskViewModel> GetTasks();

        public TaskViewModel GetTaskById(int id);

        public TaskViewModel GetTaskByName(string name);

        public void DeleteTask(int id);

        public TaskViewModel AddOrUpdateTask(int? id, TaskViewModel task);

        public bool IsValidTaskName(string name, int? id);

    }
}
