﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TasksList.Models;
using ToDoList.Services;
using static TasksList.Models.TaskViewModel;

namespace ToDoList.Controllers
{
    public class TaskController : Controller
    {

        public TaskController(ITaskService taskService) {
            this.taskService = taskService;
        }

        //Initialize with some sample tasks
        private readonly ITaskService taskService;

        [AcceptVerbs("GET", "POST")]
        public IActionResult VerifyTaskName(string name, int Id)
        {
            if (!taskService.IsValidTaskName(name, Id))
            {
                return Json($"Task {name} is already added.");
            }
            return Json(true);
        }

        // GET: TaskController
        public ActionResult Index()
        {
            var taskList = taskService.GetTasks();
            return View(taskList);
        }

        // GET: TaskController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: TaskController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind("Id,Name,Priority,TaskStatus")] TaskViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState
                    .Where(x => x.Value.Errors.Count > 0)
                    .Select(x => new
                    {
                        Field = x.Key,
                        Errors = x.Value.Errors.Select(e => e.ErrorMessage).ToArray()
                    });

                return BadRequest(new { ValidationErrors = errors });
            }

            try
            {

                taskService.AddOrUpdateTask(null, model);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: TaskController/Edit/5
        public ActionResult Edit(int id)
        {
            var task = taskService.GetTaskById(id);
            return View(task);
        }

        // POST: TaskController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                var updatedTask = new TaskViewModel();
                updatedTask.Name = collection["Name"].ToString().Trim();
                updatedTask.Priority = Convert.ToInt32(collection["Priority"]);
                updatedTask.TaskStatus = (Status)Enum.Parse(typeof(Status), collection["TaskStatus"].ToString());
                taskService.AddOrUpdateTask(id, updatedTask);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: TaskController/Delete/5
        public ActionResult Delete(int id)
        {
            var task = taskService.GetTaskById(id);
            return View(task);
        }

        // POST: TaskController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                taskService.DeleteTask(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
