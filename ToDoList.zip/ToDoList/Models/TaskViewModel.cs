﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TasksList.Models
{
    public enum Status
    {
        NotStarted = 0,
        InProgress = 1,
        Completed = 2
    }

    public class TaskViewModel
    {

        [ReadOnly(true)]
        public int Id { get; set; }


        [Required]
        [Remote(action: "VerifyTaskName", controller: "Task", AdditionalFields = "Id")]
        [StringLength(50, ErrorMessage = "Name can not be longer than 50 characters")]
        public string Name { get; set; }

        [Range(1, Int32.MaxValue, ErrorMessage ="Priority must be greater than 0!!")]
        public int Priority { get; set; }

        public Status TaskStatus { get; set; }

        public bool Deleted { get; set; }

        public TaskViewModel()
        {

        }

        public TaskViewModel(int id, string name, Status status, int priority)
        {
            Id = id;
            Name = name;
            TaskStatus = status;
            Priority = priority;
        }

    }
}
