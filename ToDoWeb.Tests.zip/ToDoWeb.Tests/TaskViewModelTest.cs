﻿using Moq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TasksList.Models;
using ToDoList.Controllers;
using ToDoList.Services;

namespace ToDoWeb.Tests
{
    public class TaskViewModelTest
    {
        [Fact]
        public void PriorityMustBeGreateThanZero()
        {
            var newTask = new TaskViewModel()
            {
                Priority = -1,
                Name = "Test 4",
                TaskStatus = Status.NotStarted
            };
            var context = new ValidationContext(newTask);
            var results = new List<ValidationResult>();
            bool isValid = Validator.TryValidateObject(newTask, context, results, true);
            Assert.False(isValid);
            Assert.Single(results);
            Assert.Equal(results[0].ErrorMessage, "Priority must be greater than 0!!");
        }

        [Fact]
        public void NameMustBeProvided()
        {
            var newTask = new TaskViewModel()
            {
                Priority = 1,
                Name = "",
                TaskStatus = Status.NotStarted
            };
            var context = new ValidationContext(newTask);
            var results = new List<ValidationResult>();
            bool isValid = Validator.TryValidateObject(newTask, context, results, true);
            Assert.False(isValid);
            Assert.Single(results);
            Assert.Equal(results[0].ErrorMessage, "The Name field is required.");
        }

    }
}
