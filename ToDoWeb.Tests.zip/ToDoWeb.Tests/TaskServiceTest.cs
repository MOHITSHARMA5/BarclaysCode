﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TasksList.Models;
using ToDoList.Controllers;
using ToDoList.Services;

namespace ToDoWeb.Tests
{
    public class TaskServiceTest
    {
        public TaskServiceTest() { }




        [Fact]
        public void AddTask()
        {
            var taskService = new TaskService();
            var tasks = taskService.GetTasks();
            var totalTasks = tasks.Count();
            var newTask = new TaskViewModel()
            {
                Priority = 1,
                Name = "Test 4",
                TaskStatus = Status.NotStarted
            };


            var context = new ValidationContext(newTask);
            var results = new List<ValidationResult>();
            bool isValid = Validator.TryValidateObject(newTask, context, results, true);


            taskService.AddOrUpdateTask(null, newTask);
            Assert.NotNull(tasks);
            var newTasks = taskService.GetTasks();
            Assert.True(totalTasks < newTasks.Count());

        }
    }
}
