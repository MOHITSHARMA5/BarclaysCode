using Microsoft.AspNetCore.Mvc;
using Moq;
using TasksList.Models;
using ToDoList.Controllers;
using ToDoList.Services;

namespace ToDoWeb.Tests
{
    public class TaskControllerTest
    {
        [Fact]
        public void IndexTest()
        {
            var taskService = new Mock<ITaskService>();
            taskService.Setup(x => x.GetTasks()).Returns(new List<TaskViewModel>()
            {
                new TaskViewModel { Id = 1, Name = "Task 1", Priority = 1 },
                new TaskViewModel { Id = 2, Name = "Task 2", Priority = 1 }
            });

            var controller = new TaskController(taskService.Object);

            var result = controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<TaskViewModel>>(
                viewResult.ViewData.Model);
            Assert.Equal(2, model.Count());

        }


    }
}